let star=document.getElementById('list')

star.onclick=function(){
    window.scrollTo({
        top: 800,
        behavior:"smooth"
    })
}

let star2=document.getElementById('list2')
star2.onclick=function(){
    window.scrollTo({
        top: 1600,
        behavior:"smooth"
    })
}


let star3=document.getElementById('down')
star3.onclick=function(){
    window.scrollTo({
        top: 10000,
        behavior:"smooth"
    })
}